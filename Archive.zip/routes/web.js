const router = require("express").Router();
const userController = require('../controllers/userController');
const mediaController = require('../controllers/mediaController');
const MediaUploader = require('../midleware/mediaUploader');

router.route("/").get(userController.login);
router.route("/create-user").post(userController.createUser);
router.route("/login").post(userController.login);
router.route("/forgot-password").post(userController.forgetPassword);
router.route("/update-profile").post(userController.updateUserById);
router.route('/upload-file').post(MediaUploader.UploadBanner.single('media'), mediaController.UploadMediaToAWS);
// router.post('/upload-media', MediaUploader.UploadBanner.single('media'), MediaUploader.UploadMediaToAWS);




// ! ||--------------------------------------------------------------------------------||
// ! ||                                  EXPORT ROUTER                                 ||
// ! ||--------------------------------------------------------------------------------||
module.exports = router;
