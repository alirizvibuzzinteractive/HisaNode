const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  role: {
    type: String,
    enum: {
      values: ["operator", "invertor","admin","staff","donor"],
    },
    required: [true, "Role is required"],
  },
  full_name: {
    type: String,
    required: [true, "Full Name is required"],
  },
  age: {
    type: Number,
  },
  cnic: {
    type: Number,
  },
  cnic_attachment_front:{
      type:String
  },
  cnic_attachment_back:{
      type:String
  },
  mobile_number:{
      type:Number
  },
  email:{
      type:String,
      trim:true,
      required:[true,"Email is required"]
  },
  password:{
      type:String,
      trim:true,
      required:[true,"Password is required"]
  },
  gender:{
      type:String,
      default:"male",
      enum:{
          values:["male","female","other"]
      }
  },
  religion:{
      type:String,
  },
  marital_status:{
    type:String,
    enum:{
        values:["single","married","divoced","widow"]
    }
  },
});

const user = mongoose.model("user", UserSchema);

module.exports = user;
